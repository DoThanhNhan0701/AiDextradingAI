import type { NextPage } from "next";
import styled from "styled-components";

const SymbolIcon = styled.img`
  height: 20.8px;
  width: 20.8px;
  position: relative;
  min-height: 21px;
`;
const AidextradingIcon = styled.img`
  height: 20.3px;
  width: 144.6px;
  position: relative;
`;
const Col = styled.div`
  width: 540px;
  border-radius: var(--br-base);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-126xl-2);
  box-sizing: border-box;
  gap: var(--gap-4xs-6);
  min-width: 540px;
  max-width: 100%;
  @media screen and (max-width: 1275px) {
    flex: 1;
  }
  @media screen and (max-width: 900px) {
    min-width: 100%;
  }
`;
const Product = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 26px;
`;
const Features = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 17px;
`;
const FeaturesParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--font-size-sm);
  color: var(--color-silver);
`;
const Col1 = styled.div`
  width: 125px;
  border-radius: var(--br-base);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Status1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 17px;
  color: var(--color-gray-600);
`;
const Links = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  min-width: 442px;
  max-width: 100%;
  gap: var(--gap-xl);
  @media screen and (max-width: 900px) {
    flex-wrap: wrap;
    min-width: 100%;
  }
`;
const FooterContent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-41xl);
  max-width: 100%;
  @media screen and (max-width: 1275px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 900px) {
    gap: var(--gap-11xl);
  }
`;
const Dot = styled.div`
  margin-top: -1px;
  margin-left: -1px;
  height: 2px;
  width: 2px;
  position: relative;
  border-radius: var(--br-11xs);
  background-color: var(--color-whitesmoke);
  flex-shrink: 0;
  debug_commit: 1de1738;
  z-index: 1;
`;
const HighlightIcon = styled.img`
  width: 320px;
  position: relative;
  max-height: unset;
  display: none;
  overflow: clip;
  z-index: 2;
`;
const GlowIcon = styled.img`
  height: 240px;
  width: 480px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  display: none;
  max-width: 100%;
  z-index: 3;
`;
const BorderIcon = styled.img`
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: clip;
  max-height: unset;
  flex-shrink: 0;
  debug_commit: 1de1738;
  margin-left: -1px;
`;
const Dot1 = styled.div`
  margin-top: -1px;
  height: 2px;
  width: 2px;
  position: relative;
  border-radius: var(--br-11xs);
  background-color: var(--color-whitesmoke);
  flex-shrink: 0;
  debug_commit: 1de1738;
  z-index: 1;
  margin-left: -1px;
`;
const Divider = styled.div`
  align-self: stretch;
  height: 0px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px 0px 0px;
  box-sizing: border-box;
  max-width: 100%;
`;
const TermsOfService = styled.div`
  position: relative;
  line-height: 17px;
  display: inline-block;
  min-width: 112px;
`;
const PrivacyPolicy = styled.div`
  position: relative;
  line-height: 17px;
  display: inline-block;
  min-width: 92px;
`;
const ReportAbuse = styled.div`
  position: relative;
  line-height: 17px;
  display: inline-block;
  min-width: 91px;
`;
const AidextradingAllRights = styled.div`
  position: relative;
  line-height: 17px;
`;
const LegalLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xl);
  @media screen and (max-width: 900px) {
    flex-wrap: wrap;
  }
`;
const FooterLegal = styled.div`
  width: 626px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs-5) 0px 0px;
  box-sizing: border-box;
  max-width: 100%;
`;
const Iconstwitter = styled.img`
  height: 14px;
  width: 14px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Button = styled.div`
  height: 32px;
  width: 32px;
  box-shadow: 0px 0px 12px rgba(255, 255, 255, 0.08) inset;
  backdrop-filter: blur(48px);
  border-radius: var(--br-19xl);
  background-color: var(--color-gray-900);
  border: 1px solid var(--color-gray-800);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const SocialButtons = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const FooterContent1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  max-width: 100%;
  gap: var(--gap-xl);
  @media screen and (max-width: 900px) {
    flex-wrap: wrap;
  }
`;
const Layout = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-21xl);
  box-sizing: border-box;
  gap: var(--gap-41xl);
  max-width: 100%;
  z-index: 2;
  font-size: var(--font-size-sm);
  color: var(--color-gray-700);
  @media screen and (max-width: 900px) {
    gap: var(--gap-11xl);
  }
`;
const FooterLayout = styled.div`
  width: 1280px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-41xl);
  max-width: 100%;
  @media screen and (max-width: 900px) {
    gap: var(--gap-11xl);
  }
`;
const FooterContainerRoot = styled.footer`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: 0px var(--padding-xl);
  box-sizing: border-box;
  max-width: 100%;
  text-align: left;
  font-size: var(--font-size-base);
  color: var(--color-whitesmoke);
  font-family: var(--font-inter);
`;

const FrameComponent: NextPage = () => {
  return (
    <FooterContainerRoot>
      <FooterLayout>
        <FooterContent>
          <Col>
            <SymbolIcon alt="" src="/symbol.svg" />
            <AidextradingIcon alt="" src="/aidextrading.svg" />
          </Col>
          <Links>
            <Col1>
              <Product>Product</Product>
              <FeaturesParent>
                <Features>Features</Features>
                <Features>Docs</Features>
                <Features>Integrations</Features>
              </FeaturesParent>
            </Col1>
            <Col1>
              <Product>Company</Product>
              <FeaturesParent>
                <Features>About</Features>
                <Features>Blog</Features>
                <Features>Customers</Features>
              </FeaturesParent>
            </Col1>
            <Col1>
              <Product>Resources</Product>
              <FeaturesParent>
                <Features>Community</Features>
                <Features>Contact</Features>
                <Features>Privacy policy</Features>
                <Features>Terms of use</Features>
              </FeaturesParent>
            </Col1>
            <Col1>
              <Product>Developers</Product>
              <FeaturesParent>
                <Features>API</Features>
                <Status1>Status</Status1>
              </FeaturesParent>
            </Col1>
          </Links>
        </FooterContent>
        <Layout>
          <Divider>
            <Dot />
            <HighlightIcon alt="" src="/highlight1.svg" />
            <GlowIcon alt="" src="/glow1.svg" />
            <BorderIcon loading="lazy" alt="" src="/border.svg" />
            <Dot1 />
          </Divider>
          <FooterContent1>
            <FooterLegal>
              <LegalLinks>
                <TermsOfService>Terms of Service</TermsOfService>
                <PrivacyPolicy>Privacy Policy</PrivacyPolicy>
                <ReportAbuse>Report Abuse</ReportAbuse>
                <AidextradingAllRights>
                  ©2024 AiDexTrading. All rights reserved.
                </AidextradingAllRights>
              </LegalLinks>
            </FooterLegal>
            <SocialButtons>
              <Button>
                <Iconstwitter loading="lazy" alt="" src="/iconstwitter.svg" />
              </Button>
              <Button>
                <Iconstwitter loading="lazy" alt="" src="/x.svg" />
              </Button>
              <Button>
                <Iconstwitter loading="lazy" alt="" src="/iconsinstagram.svg" />
              </Button>
              <Button>
                <Iconstwitter loading="lazy" alt="" src="/iconsdiscord.svg" />
              </Button>
            </SocialButtons>
          </FooterContent1>
        </Layout>
      </FooterLayout>
    </FooterContainerRoot>
  );
};

export default FrameComponent;
